﻿namespace GGAssignment3
{
    partial class TicTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNextPlay = new System.Windows.Forms.TextBox();
            this.lblGoNext = new System.Windows.Forms.Label();
            this.lblScoreboard = new System.Windows.Forms.Label();
            this.txtXWins = new System.Windows.Forms.TextBox();
            this.lblXWins = new System.Windows.Forms.Label();
            this.lblOWins = new System.Windows.Forms.Label();
            this.txtOWins = new System.Windows.Forms.TextBox();
            this.lblTies = new System.Windows.Forms.Label();
            this.txtTie = new System.Windows.Forms.TextBox();
            this.btnResetGame = new System.Windows.Forms.Button();
            this.btnResetScores = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNextPlay
            // 
            this.txtNextPlay.Enabled = false;
            this.txtNextPlay.Location = new System.Drawing.Point(29, 74);
            this.txtNextPlay.Name = "txtNextPlay";
            this.txtNextPlay.Size = new System.Drawing.Size(100, 20);
            this.txtNextPlay.TabIndex = 0;
            // 
            // lblGoNext
            // 
            this.lblGoNext.AutoSize = true;
            this.lblGoNext.Location = new System.Drawing.Point(26, 49);
            this.lblGoNext.Name = "lblGoNext";
            this.lblGoNext.Size = new System.Drawing.Size(68, 13);
            this.lblGoNext.TabIndex = 1;
            this.lblGoNext.Text = "To play next:";
            // 
            // lblScoreboard
            // 
            this.lblScoreboard.AutoSize = true;
            this.lblScoreboard.Location = new System.Drawing.Point(26, 128);
            this.lblScoreboard.Name = "lblScoreboard";
            this.lblScoreboard.Size = new System.Drawing.Size(85, 13);
            this.lblScoreboard.TabIndex = 2;
            this.lblScoreboard.Text = "SCOREBOARD:";
            // 
            // txtXWins
            // 
            this.txtXWins.Enabled = false;
            this.txtXWins.Location = new System.Drawing.Point(32, 186);
            this.txtXWins.Name = "txtXWins";
            this.txtXWins.Size = new System.Drawing.Size(100, 20);
            this.txtXWins.TabIndex = 3;
            // 
            // lblXWins
            // 
            this.lblXWins.AutoSize = true;
            this.lblXWins.Location = new System.Drawing.Point(29, 161);
            this.lblXWins.Name = "lblXWins";
            this.lblXWins.Size = new System.Drawing.Size(17, 13);
            this.lblXWins.TabIndex = 4;
            this.lblXWins.Text = "X:";
            // 
            // lblOWins
            // 
            this.lblOWins.AutoSize = true;
            this.lblOWins.Location = new System.Drawing.Point(29, 220);
            this.lblOWins.Name = "lblOWins";
            this.lblOWins.Size = new System.Drawing.Size(18, 13);
            this.lblOWins.TabIndex = 5;
            this.lblOWins.Text = "O:";
            // 
            // txtOWins
            // 
            this.txtOWins.Enabled = false;
            this.txtOWins.Location = new System.Drawing.Point(32, 242);
            this.txtOWins.Name = "txtOWins";
            this.txtOWins.Size = new System.Drawing.Size(100, 20);
            this.txtOWins.TabIndex = 6;
            // 
            // lblTies
            // 
            this.lblTies.AutoSize = true;
            this.lblTies.Location = new System.Drawing.Point(29, 275);
            this.lblTies.Name = "lblTies";
            this.lblTies.Size = new System.Drawing.Size(25, 13);
            this.lblTies.TabIndex = 7;
            this.lblTies.Text = "Tie:";
            // 
            // txtTie
            // 
            this.txtTie.Enabled = false;
            this.txtTie.Location = new System.Drawing.Point(32, 313);
            this.txtTie.Name = "txtTie";
            this.txtTie.Size = new System.Drawing.Size(100, 20);
            this.txtTie.TabIndex = 8;
            // 
            // btnResetGame
            // 
            this.btnResetGame.Location = new System.Drawing.Point(29, 388);
            this.btnResetGame.Name = "btnResetGame";
            this.btnResetGame.Size = new System.Drawing.Size(100, 23);
            this.btnResetGame.TabIndex = 9;
            this.btnResetGame.Text = "Reset Game";
            this.btnResetGame.UseVisualStyleBackColor = true;
            this.btnResetGame.Click += new System.EventHandler(this.btnResetGame_Click);
            // 
            // btnResetScores
            // 
            this.btnResetScores.Location = new System.Drawing.Point(29, 427);
            this.btnResetScores.Name = "btnResetScores";
            this.btnResetScores.Size = new System.Drawing.Size(100, 23);
            this.btnResetScores.TabIndex = 10;
            this.btnResetScores.Text = "Reset Scores";
            this.btnResetScores.UseVisualStyleBackColor = true;
            this.btnResetScores.Click += new System.EventHandler(this.btnResetScores_Click);
            // 
            // TicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 529);
            this.Controls.Add(this.btnResetScores);
            this.Controls.Add(this.btnResetGame);
            this.Controls.Add(this.txtTie);
            this.Controls.Add(this.lblTies);
            this.Controls.Add(this.txtOWins);
            this.Controls.Add(this.lblOWins);
            this.Controls.Add(this.lblXWins);
            this.Controls.Add(this.txtXWins);
            this.Controls.Add(this.lblScoreboard);
            this.Controls.Add(this.lblGoNext);
            this.Controls.Add(this.txtNextPlay);
            this.Name = "TicTacToe";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.TicTacToe_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNextPlay;
        private System.Windows.Forms.Label lblGoNext;
        private System.Windows.Forms.Label lblScoreboard;
        private System.Windows.Forms.TextBox txtXWins;
        private System.Windows.Forms.Label lblXWins;
        private System.Windows.Forms.Label lblOWins;
        private System.Windows.Forms.TextBox txtOWins;
        private System.Windows.Forms.Label lblTies;
        private System.Windows.Forms.TextBox txtTie;
        private System.Windows.Forms.Button btnResetGame;
        private System.Windows.Forms.Button btnResetScores;
    }
}

