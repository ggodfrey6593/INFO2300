﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GGAssignment3
{
    public partial class TicTacToe : Form
    {
        //declaring constants
        private const int LEFT = 250;
        private const int TOP = 75;
        private const int VGAP = 5;
        private const int ROW = 3;
        private const int COL = 3;
        private const int WIDTH = 100;
        private const int HEIGHT = 100;

        //creating image links to resources
        Image xPicture = GGAssignment3.Properties.Resources.x;
        Image oPicture = GGAssignment3.Properties.Resources.O;
        List<PictureBox> tiles = new List<PictureBox>();
        PictureBox[,] grid = new PictureBox[3, 3];
        int nextPlay = 0;
        int winX = 0;
        int winO = 0;
        int tie = 0;

        public TicTacToe()
        {
            InitializeComponent();
        }

        /// <summary>
        /// running Create function on form load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TicTacToe_Load(object sender, EventArgs e)
        {
            CreateBoard();
        }

        /// <summary>
        /// Creating picturebox grid for playing tic tac toe
        /// </summary>
        public void CreateBoard()
        {
            int y = TOP;
            int x = LEFT;

            for (int i = 0; i < ROW; i++)
            {
                x = LEFT;
                for (int p = 0; p < COL; p++)
                {
                    PictureBox q = new PictureBox();
                    q.Left = x;
                    q.Top = y;
                    q.Width = WIDTH;
                    q.Height = HEIGHT;
                    q.SizeMode = PictureBoxSizeMode.StretchImage;
                    q.BorderStyle = BorderStyle.FixedSingle;
                    grid[i, p] = q;
                    tiles.Add(q);

                    q.Click += playArea_Click;
                    this.Controls.Add(q);

                    x += VGAP + HEIGHT;
                }

               y += VGAP + HEIGHT;
            }
            txtNextPlay.Text = "X";
        }



        /// <summary>
        /// creating the on click interaction with the playarea. checking for 
        /// nextPlay value in order to determing what image to populate.
        /// this also calls the win check function
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void playArea_Click(object sender, EventArgs e)
        {
            PictureBox tile = (PictureBox)sender;
            tile.SizeMode = PictureBoxSizeMode.StretchImage;

            if (nextPlay == 0)
            {
                tile.Image = xPicture;
                txtNextPlay.Text = "O";
                tile.Enabled = false;
                nextPlay = 1;
            }
            else if (nextPlay == 1)
            {
                tile.Image = oPicture;
                txtNextPlay.Text = "X";
                tile.Enabled = false;
                nextPlay = 0;
            }

            Winner(tile.Image);
        }

        /// <summary>
        /// function to determine a winner using grid results
        /// </summary>
        /// <param name="nextPlay"></param>
        public void Winner(Image img)
        {
            //there are limited ways to win tick tac toe
            //these if statements go over all possibilities

            if (grid[0, 0].Image == img && grid[0, 1].Image == img && grid[0, 2].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[1, 0].Image == img && grid[1, 1].Image == img && grid[1, 2].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[2, 0].Image == img && grid[2, 1].Image == img && grid[2, 2].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[0, 0].Image == img && grid[1, 1].Image == img && grid[2, 2].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[0, 2].Image == img && grid[1, 1].Image == img && grid[2, 0].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[0, 0].Image == img && grid[1, 0].Image == img && grid[2, 0].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[0, 1].Image == img && grid[1, 1].Image == img && grid[2, 1].Image == img)
            {
                DisplayWinner(img);
            }
            if (grid[0, 2].Image == img && grid[1, 2].Image == img && grid[2, 2].Image == img)
            {
                DisplayWinner(img);
            }

            //looking for full playarea and calling a tie if there is no winner
            int full = 0;
            foreach (var tile in grid)
            {
                if(tile.Image != null)
                {
                    full++;
                }
            }
            if(full == 9)
            {
                MessageBox.Show("Tie!");
                tie++;
                txtTie.Text = Convert.ToString(tie);
                foreach(var tile in tiles)
                {
                    this.Controls.Remove(tile);

                }
                nextPlay = 0;
                CreateBoard();
            }
        }
        /// <summary>
        /// displaying a winner
        /// </summary>
        /// <param name="img"></param>
        public void DisplayWinner(Image img)
        {
            if (img == xPicture)
            {
                MessageBox.Show("X WINS!");
                winX++;
                txtXWins.Text = Convert.ToString(winX);
            }
            else
            {
                MessageBox.Show("O WINS!");
                winO++;
                txtOWins.Text = Convert.ToString(winO);
            }

            nextPlay = 0;
            CreateBoard();

        }

        

        /// <summary>
        /// Resets game
        /// </summary>
        private void btnResetGame_Click(object sender, EventArgs e)
        {
            foreach (var tile in tiles)
            {
                this.Controls.Remove(tile);
            }
            nextPlay = 0;
            CreateBoard();
        }

        ///<summary>
        ///Resets the scoreboard
        /// </summary>
        ///<param name="sender"></param>
        /// <param name="e"></param>
        private void btnResetScores_Click(object sender, EventArgs e)
        {
            winX = 0;
            winO = 0;
            tie = 0;
            txtOWins.Text = "";
            txtXWins.Text = "";
            txtTie.Text = "";
        } 

    }

}



